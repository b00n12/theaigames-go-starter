#ifndef MOVE_H
#define MOVE_H

#include <stdbool.h>

typedef struct Move {
    bool is_pass;
    unsigned int x_pos;
    unsigned int y_pos;

    /*
     * Needed for usage of utlist
     */
    struct Move *prev;
    struct Move *next;
} Move;

#endif