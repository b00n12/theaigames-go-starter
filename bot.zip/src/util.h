#ifndef UTIL_H
#define UTIL_H

long random_at_most(long max);

char *str_replace(char *str, char *to_replace, char *replacement);

char **str_split(char *str, char *delimiter);

#endif