#include "bot.h"

Move make_move(long time) {
    Move move;
    move.is_pass = true;
    return move;
}