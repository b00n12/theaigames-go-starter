#ifndef BOT_H
#define BOT_H

#include "../move/move.h"

Move make_move(long time);

#endif