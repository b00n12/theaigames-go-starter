#ifndef BOT_STATE_H
#define BOT_STATE_H

#include "../move/move.h"

#define INITIALVALUE16 0xFFFF
#define INITIALVALUE32 0xFFFFFFFF
#define INITIALVALUE64 0xFFFFFFFFFFFFFFFF

typedef struct Settings {
    unsigned short my_bot_id;
    unsigned short opponent_bot_id;
    unsigned long timebank;
    unsigned long time_per_move;
    unsigned int field_width;
    unsigned int field_height;
    unsigned int max_rounds;
} Settings;

extern Settings g_game_settings;

typedef struct BotState {
    unsigned int round;
    short **field;
    unsigned int tot_num_moves;
    unsigned int my_points;
    unsigned int opponent_points;
    Move my_last_move;
    Move opponent_last_move;
} BotState;

extern BotState g_bot_state;

#endif
