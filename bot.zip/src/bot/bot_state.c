#include "bot_state.h"

Settings g_game_settings = {
    .my_bot_id = INITIALVALUE16,
    .opponent_bot_id = INITIALVALUE16,
    .timebank = INITIALVALUE64,
    .time_per_move = INITIALVALUE64,
    .field_width = INITIALVALUE32,
    .field_height = INITIALVALUE32,
    .max_rounds = INITIALVALUE32
};

BotState g_bot_state;
